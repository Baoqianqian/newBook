const express = require('express');
var pool = require('./z_pool')
var router = express.Router();


//模糊搜索
router.get('/search',(req,res)=>{
	var json = req.query;
	console.log(json);
	pool.conn({
		arr:[json.name],
		sql:`select * from create_book where bookname like "%${json.name}%"`,
		success(data){
			console.log(data)
			res.send(data)
		},
		error(err){
			res.send(err)
		}
	})
})


router.get('/z_search',(req,res)=>{
	var json = req.query;
	console.log(json);
	pool.conn({
		arr:[json.name],
		sql:`select * from create_book where bookname like "%${json.name}%"`,
		success(data){
			console.log(data)
			res.send(data)
		},
		error(err){
			res.send(err)
		}
	})
})


module.exports = router


