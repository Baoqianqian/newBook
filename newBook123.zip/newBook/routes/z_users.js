var express = require('express');
var router = express.Router();
var pool = require('./z_pool')
/* GET users listing. */
router.get('/', function(req, res, next) {
	res.send('respond with a resource');
});

//注册
router.post('/in', function(req, res) {
	var json = req.body;
	console.log(json);
	pool.conn({
		arr: [json.user],
		sql: 'select user from login where user=?',
		success(data) {
			if(data.length) {
				res.send('账号已存在');
			} else {
				pool.conn({
					arr: [json.user, json.pass, json.name, json.imgurl],
					sql: 'insert into login(user,pass,name,imgurl) values(?,?,?,?)',
					success(data) {
						res.send('注册成功了');
					},
					error(err) {
						res.send(err)
					}
				})
			}
		},
		error(err) {
			res.send(err);
		}
	})
})

//登录
router.post('/up', (req, res) => {
	var json = req.body;
	pool.conn({
		arr: [json.user, json.pass],
		sql: 'select * from login where user=? and pass=?',
		success(data) {
			if(data.length) {
				data[0].pass = '';
				res.send(data[0]);
			} else {
				res.send('账号密码不匹配');
			}
		},
		error(err) {
			res.send(err);
		}
	})
})

//获取数据库里的小说数据
router.get('/z_books', (req, res) => {
	var json = req.query;
	console.log(json);
	pool.conn({
		arr: [],
		sql: `select * from create_book`,
		success(data) {
			res.send(data)
		},
		error(err) {
			res.send(err)
		}
	})
})

module.exports = router;